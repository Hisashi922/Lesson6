# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'ded5cfa0b3ad71b5202559ad88d7a0c43fac778fb6b2d88edf4ec0a7017961601e235e98b939c1d2104854a6afdf35f74a7a6b730da9c0d98aaa720fe904962b'